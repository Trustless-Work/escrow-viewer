// src/utils/token-balance.ts
export {
  sacContractIdFromAsset,
  fetchTokenBalance,
  fetchTokenDecimals,
} from "@/lib/token-service";
