// utils/token-balance.ts
import {
  Address,
  Asset,
  Contract,
  Keypair,
  Networks,
  TransactionBuilder,
  xdr,
} from "@stellar/stellar-sdk";
import { NetworkType, getNetworkConfig } from "@/lib/network-config";

/**
 * Resolve SAC (Stellar Asset Contract) ID from classic asset (code+issuer).
 * Your SDK exposes this as Asset.contractId(passphrase).
 */
export function sacContractIdFromAsset(
  code: string,
  issuer: string,
  passphrase: string
): string {
  const a = new Asset(code, issuer);
  return a.contractId(passphrase);
}

type JsonRpcResponse<T> = {
  jsonrpc: "2.0";
  id: number | string | null;
  result?: T;
  error?: { code: number; message: string; data?: unknown };
};

async function jsonRpcCall<T>(
  rpcUrl: string,
  method: string,
  params: unknown
): Promise<T> {
  const res = await fetch(rpcUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: 1,
      method,
      params,
    }),
  });
  if (!res.ok) throw new Error(`RPC ${method} HTTP ${res.status}`);
  const json = (await res.json()) as JsonRpcResponse<T>;
  if (json.error) throw new Error(`${method} error: ${json.error.message}`);
  if (!json.result) throw new Error(`${method} returned no result`);
  return json.result;
}

/**
 * Call token.balance(Address) via Soroban RPC simulate (read-only), no SDK server wrapper.
 */
export async function fetchTokenBalance({
  tokenContractId,
  ownerAddress, // "CA..." (contract) or "GA..." (account)
  network,
}: {
  tokenContractId: string;
  ownerAddress: string;
  network: NetworkType;
}): Promise<bigint> {
  const cfg = getNetworkConfig(network);
  const rpcUrl = cfg.rpcUrl;
  const passphrase =
    cfg.networkPassphrase ??
    (network === "mainnet" ? Networks.PUBLIC : Networks.TESTNET);

  // 1) Get latest ledger (sequence) to build a tx
  const latest = await jsonRpcCall<{ sequence: number }>(rpcUrl, "getLatestLedger", {});

  // 2) Build simulate tx calling token.balance(address)
  const source = Keypair.random();
  const fakeAccount = {
    accountId: () => source.publicKey(),
    sequenceNumber: () => String(latest.sequence),
    incrementSequenceNumber: function () {},
  };

  const token = new Contract(tokenContractId);

  // Build ScVal address argument expected by the token contract
  const scAddr = Address.fromString(ownerAddress).toScAddress();
  const scvOwner = xdr.ScVal.scvAddress(scAddr);

  const op = token.call("balance", scvOwner);

  const tx = new TransactionBuilder(fakeAccount as any, {
    fee: "10000",
    networkPassphrase: passphrase,
  })
    .addOperation(op)
    .setTimeout(30)
    .build();

  const txB64 = tx.toXDR();

  // 3) Simulate
  const sim = await jsonRpcCall<{
    result: { retval: string }; // base64-encoded ScVal
    // other fields omitted
  }>(rpcUrl, "simulateTransaction", { transaction: txB64 });

  const retvalB64 = sim.result?.retval;
  if (!retvalB64) throw new Error("simulateTransaction returned no retval");

  const scv = xdr.ScVal.fromXDR(retvalB64, "base64");
  if (scv.switch() !== xdr.ScValType.scvI128()) {
    throw new Error("token.balance returned non-i128");
  }

  // Compose i128.hi/lo to bigint without bigint literals
  const i128 = scv.i128();
  const hi = BigInt(i128.hi().toString());
  const lo = BigInt(i128.lo().toString());
  const TWO_POW_64 = BigInt(2) ** BigInt(64);
  const value = hi * TWO_POW_64 + lo;

  return value;
}

export async function fetchTokenDecimals({
  tokenContractId,
  network,
}: {
  tokenContractId: string;
  network: NetworkType;
}): Promise<number> {
  const cfg = getNetworkConfig(network);
  const rpcUrl = cfg.rpcUrl;

  // Build a simulate tx calling token.decimals()
  const source = Keypair.random();
  // A recent sequence is not strictly needed for simulate, but we'll keep parity with balance call
  const latest = await (async function getLatestLedger() {
    const res = await fetch(rpcUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "getLatestLedger", params: {} }),
    });
    const j = await res.json();
    if (j.error) throw new Error(j.error.message || "getLatestLedger failed");
    return j.result;
  })();

  const passphrase = cfg.networkPassphrase ??
    (network === "mainnet" ? Networks.PUBLIC : Networks.TESTNET);

  const fakeAccount = {
    accountId: () => source.publicKey(),
    sequenceNumber: () => String(latest.sequence),
    incrementSequenceNumber: function () {},
  };

  const token = new Contract(tokenContractId);
  const op = token.call("decimals"); // no args

  const tx = new TransactionBuilder(fakeAccount as any, {
    fee: "10000",
    networkPassphrase: passphrase,
  })
    .addOperation(op)
    .setTimeout(30)
    .build();

  const txB64 = tx.toXDR();
  const res = await fetch(rpcUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: 1,
      method: "simulateTransaction",
      params: { transaction: txB64 },
    }),
  });
  const json = await res.json();
  if (json.error) throw new Error(json.error.message || "simulate decimals failed");

  const retvalB64 = json.result?.result?.retval;
  if (!retvalB64) throw new Error("simulate decimals returned no retval");

  const scv = xdr.ScVal.fromXDR(retvalB64, "base64");

  // Common token impls use u32 for decimals
  if (scv.switch() === xdr.ScValType.scvU32()) {
    return scv.u32();
  }
  // Some might use u8
  if (scv.switch() === xdr.ScValType.scvU64()) {
    // extremely rare; handle defensively
    return Number(scv.u64());
  }
  if (scv.switch() === xdr.ScValType.scvU128()) {
    return Number(scv.u128()); // defensive
  }
  throw new Error("Unexpected decimals return type");
}
